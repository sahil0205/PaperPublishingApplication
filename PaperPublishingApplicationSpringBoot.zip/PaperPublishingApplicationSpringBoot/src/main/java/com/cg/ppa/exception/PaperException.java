package com.cg.ppa.exception;

public class PaperException extends RuntimeException{
	public PaperException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
